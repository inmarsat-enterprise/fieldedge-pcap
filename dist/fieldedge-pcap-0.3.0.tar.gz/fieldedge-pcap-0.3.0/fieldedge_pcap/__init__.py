"""
.. include:: ../README.md
"""